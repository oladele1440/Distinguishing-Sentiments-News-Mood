

```python
# Importing Dependencies
import tweepy
import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import time
import seaborn as sns
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
```


```python
#My Twitter Api Keys
consumer_key = "UNPPyTYNQcbAYqnZjNEsDoCpd"
consumer_secret= "0vIru56101Lde0ZXVMD1Zr3gUvQzXvdzNDFkrhhvQtB45FFIC9"
access_token = "516464404-qT3jpDj0LI1j7XMrfKjV2V4IMqZ1u10KCepT30rn"
access_token_secret= "par4pvQ6i4ARdcit6FbFb9OLnD633c7Ms5qnQiaCrqo19"

```


```python
# Setting up Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
# Targeting Media Search Term
news_outlet = ["@BBC", "@CBS", "@CNN", "@Fox", "@nytimes"]
counter = 1
sentiments =[]
```


```python
for outlet in news_outlet:
    public_tweets = api.user_timeline(outlet, count=100)
    tweetnumber = 1       
    for tweet in public_tweets:
        print("Tweet %s: %s" % (counter, tweet["text"]))
        compound = analyzer.polarity_scores(tweet["text"])["compound"]
        pos = analyzer.polarity_scores(tweet["text"])["pos"]
        neu = analyzer.polarity_scores(tweet["text"])["neu"]
        neg = analyzer.polarity_scores(tweet["text"])["neg"]
        tweets_ago = tweetnumber
        sentiments.append({"Media Source": outlet,
                           "Text":tweet["text"],
                           "Date": tweet["created_at"],
                           "Compound": compound,
                           "Positive": pos,
                           "Neutral": neu,
                           "Negative": neg,
                           "Tweet Count": tweetnumber})
        tweetnumber +=1
        counter +=1
```

    Tweet 1: RT @BBCOne: They've finally quacked the case.
    
    https://t.co/eq4dLcauhe
    Tweet 2: RT @BBCEarth: Sudan’s death leaves just two females of the subspecies alive in the world 
    https://t.co/kCpRCxFaFY
    Tweet 3: RT @bbcthree: RuPaul is the first drag queen to get a Hollywood star. Sissy that Walk of Fame.  https://t.co/SmqOPQizh3 https://t.co/hWb1Xm…
    Tweet 4: RT @BBCBreakfast: ❄️❄️BBRRR....Could it be the coldest day yet for the Spring Equinox?
    Let us know what temp it is where you are today.  #S…
    Tweet 5: Meet Bumblebee and Gnat, two adorable badger cubs being raised at an animal sanctuary. 😍
    https://t.co/Ihami0VtL0
    Tweet 6: Spring is here! But what is the #SpringEquinox? 🌺🌻🌸🌱https://t.co/RiWP3PC7Yo https://t.co/FIKocYFP6C
    Tweet 7: Five times Beyonce and Jay-Z’s daughter Blue Ivy outshone her parents. ⭐️ https://t.co/JaNAzsofOm https://t.co/DnoyApY0yL
    Tweet 8: Traditional Highland Games sports such as tossing the caber and tug-of-war are to be taught in PE lessons. 🏆… https://t.co/jv5wlpmlyT
    Tweet 9: Follow the dramatic and deadly series of events that took place at two funerals in Belfast in March 1988. 
    
    The Fun… https://t.co/y3MZaR8hsi
    Tweet 10: Leonardo DiCaprio stars in the true story of a con man who cashed fake cheques worth millions. 
    
    Catch Me If You Ca… https://t.co/HWShPj9ngi
    Tweet 11: 😂📸 @AlanCarr learned the hard way that you only get one shot at a school photo. #LiveAtTheApollo 
    
    https://t.co/fv5JmcRgz4
    Tweet 12: 🎤Pop band @FifthHarmony have announced they're taking a break to pursue solo careers 🎶https://t.co/tLOR7h1gZy https://t.co/5c77Cfjfp6
    Tweet 13: Murder. Innocence. Lies. 
    
    @AgathaChristie classic, #OrdealByInnocence, comes to @BBCOne soon.
    https://t.co/qfJThHowXC
    Tweet 14: Here are the latest snow scenes from around the UK. ❄️📸 https://t.co/eTBGkQ4MPU https://t.co/txRHxkOn5C
    Tweet 15: 'Flabbergasted'. 🎶This is the incredible moment when eight London teenagers heard a live opera singer for the first… https://t.co/jNki4Z61SE
    Tweet 16: Meet the dancing slum kids tipped for stardom by Rihanna 🎶
    https://t.co/R61fzQGIzd https://t.co/wGcvBKmdaZ
    Tweet 17: RT @bbcgetinspired: The Nation's Billion Steps Challenge is here! 🙌 
    
    Yesterday we did an amazing 431 million steps – can we do even better…
    Tweet 18: 💭 "There's always that voice in the back of your head that says you're not good enough". 
    
     💪 @CarrieHFletcher on b… https://t.co/0AsBxFFiQA
    Tweet 19: RT @BBCRadioScot: This must have been some buzz! 🐝🐝🐝 https://t.co/0gqtbQBN1i
    Tweet 20: Where are the UK's youngest and oldest city populations? https://t.co/eIU7UzqHBS https://t.co/vdXMTDluuX
    Tweet 21: RT @BBCSport: This 102-shot badminton rally will leave you exhausted... https://t.co/LFC4r4iwiz
    Tweet 22: Have you got a passion for plants? 🌿🌸🌱🍃🌷
    
    Test your knowledge of all things foliage in this quiz. 👉… https://t.co/evogV5ljAc
    Tweet 23: RT @BBCSport: 🎉 The Commonwealth Games are almost upon us! 🎉
    
    Scotland's Lynsey Sharp has given us the inside track on preparing for succes…
    Tweet 24: The oldest dog that the Dogs Trust has ever looked after has been given a new home. ❤️️🐶https://t.co/h0WQHkfMEf https://t.co/ixb7gesOIj
    Tweet 25: RT @BBCR1: Desperately searching for any signs of spring like... 🌸
    
    #MondayMotivation https://t.co/9jo3h4C7bu
    Tweet 26: RT @BBCRadioWales: ❄️ Snowy Cardiff! ⛄️ 
    
    What’s it like for you?
    
    #ButePark 
    #Cardiff 
    #MiniBeast
    #Snow https://t.co/O8gY1qjHVE
    Tweet 27: RT @BBCNews: Stem cell transplant "game changer" for MS patients https://t.co/BGWtdtXUAP
    Tweet 28: RT @BBCBreakfast: Anyone want to play a game of spot Tracey's feet? Our floor manager Tracey had to dive behind the sofa to avoid being on…
    Tweet 29: 'Who wants a normal life?' We should all be a little more like @chessmartinez. 👏💖 #LiveAtTheApollo
    
    https://t.co/VddL8zWJfS
    Tweet 30: RT @BBCWthrWatchers: Some incredible photos sent in last night of the #Auroraborealis from Skye Woody, Cumbrian stargazer and DJStewie.  Di…
    Tweet 31: Beautiful spring blossom in south-west China has been captured by drone https://t.co/WTo7JjiKXw
    Tweet 32: 🤔 Should we still be worried about the hole in the ozone layer?
    
    🌤 @SimonOKing and @clarenasir investigate in their… https://t.co/SZV3Df9y0t
    Tweet 33: 🏃💪 @LesDennis, @SimplySusannah, @Tameka_Empson and Miles Jupp embark on a muscle-grinding mission to regain their f… https://t.co/B1rXaalmk2
    Tweet 34: 👎💌 Fans of K-Pop boyband member @IBGDRGN have been asked to stop sending fan mail to the army base where he's doing… https://t.co/ojtDZ3gMfb
    Tweet 35: Saoirse Ronan stars as Eilis, a young girl who jumps at the chance of a better life when she emigrates to New York.… https://t.co/NtHAfh6cjZ
    Tweet 36: Ruth Ellis was only 28 when she became the last woman hanged to death in the UK. 
    
    #TheRuthEllisFiles | Watch on… https://t.co/5kUIFtom7t
    Tweet 37: RT @BBC_TopGear: 840bhp goes a little like this…
    
    @Matt_LeBlanc takes the Dodge Challenger SRT #Demon to the drag strip in this Sunday’s @T…
    Tweet 38: RT @bbcthree: Be honest, do you think you'll be this fit at 81? https://t.co/Eca0uGCF6b
    Tweet 39: 🍎🗑 How much food do you throw away? If you're a typical Brit, you probably think it's hardly any.
    
    You're in denial… https://t.co/0bSCbRrZJr
    Tweet 40: ❤️️📸Zun Lee wants his photography to give a balanced and nuanced portrayal of black fatherhood.
    
    👉… https://t.co/LodRrr27fd
    Tweet 41: 🤰 A doctor explains why you can get pregnant and give birth without having a baby bump. 
    👉 https://t.co/nVrSpQoTOT https://t.co/iEEOjZdBKL
    Tweet 42: RT @BBCEngland: A number of runners have held their own half-marathon in Reading after the official event was called off due to the snowy w…
    Tweet 43: RT @BBCSport: They’ve done it! Gold for GB’s Menna Fitzpatrick and Jen Kehoe in the visually impaired slalom at the Winter Paralympics. And…
    Tweet 44: 📱🚗 Why a rise in electric cars could also mean a hike in the cost of your next phone. https://t.co/6i5xFQgRIW
    Tweet 45: RT @BBC6Music: ✏️ Which song has the greatest opening line?
    Tweet 46: 🎤Pop music is awash with those that released one hit album and never followed it up. Here are 7 huge artists that o… https://t.co/4ukT9drcdG
    Tweet 47: 🍔😲 Would you eat a burger pie?  
    #BackInTimeForTea https://t.co/zGWzJwdSlM
    Tweet 48: RT @BBCOne: If food is the language of love... https://t.co/5hnYovE94o
    Tweet 49: Ever wondered why David Bowie wore an eye patch?
    
    Strange things artists have worn on stage and the reasons why. 
    👉… https://t.co/8zSBXQkLvy
    Tweet 50: 🍞🥖 Want to learn how to bake bread?
    
    These easy to follow recipes and step-by-step videos will have you baking ever… https://t.co/iXEmj5WJdD
    Tweet 51: “I regret spending £50,000 on my wedding.” https://t.co/6PxJsDf9dn https://t.co/eJdx7KMmmK
    Tweet 52: How to be 20 on the inside, even when you’re 80 on the outside... https://t.co/KB2mqpkrIB
    Tweet 53: RT @BBCNews: Snow and ice are bringing disruption to many parts of the UK - but they're not stopping everyone from having fun 🐶❄️
    
    https://…
    Tweet 54: RT @bbc5live: The beast from the east is back ❄️🌨️
    
    You've been in touch this morning with your #uksnow pics, here are just a few...
    
    What'…
    Tweet 55: These seven celebrities are about to go on the journey of a lifetime... #Pilgrimage
    https://t.co/m45UBXJew2
    Tweet 56: Can we just take a moment to discuss Eddie Redmanyne's coats?https://t.co/odVkhWyRKs
    Tweet 57: Ouch! 😂🔥@GordonRamsay's daughter is hilarious... 
    https://t.co/0dqwntX5uj
    Tweet 58: 🐜1⃣2⃣3⃣Sir David Attenborough explores whether there is counting in the natural world. 
    
    David Attenborough's Natur… https://t.co/Q4H4uXR4pt
    Tweet 59: One of the writers for The Simpsons has told @BBCNewsbeat Stephen Hawking was such a big fan of the show - he'd sho… https://t.co/Jjer3V4cYk
    Tweet 60: 🎓📚 'The moment I gave Reese Witherspoon my Legally Blonde dissertation... and yes, it was scented.'
    👉… https://t.co/z8x5mqqKoW
    Tweet 61: RT @BBCWorld: Blossom in south-west China captured by drone https://t.co/gIDKUn1La6
    Tweet 62: This year, over 250 landmarks across the globe are going green for #StPatricksDay! 🍀 https://t.co/TlWqU0TXQT https://t.co/i4sW4OaGrQ
    Tweet 63: RT @BBCRadio3: "Even if we found a complete theory of the universe, it wouldn't remove the need for music" - #StephenHawking
    https://t.co/t…
    Tweet 64: ⛷❤️ George has autism and other health conditions - but his love of skiing is helping him take on the outside world. https://t.co/kfCzRzkcNY
    Tweet 65: RT @5liveSport: 'My mates didn't know I was playing @realmadrid'
    
    @ManUtd's @carras16 tells @ColinMurray his friends keep him grounded…
    
    'A…
    Tweet 66: Yes, Gary Oldman and @BBCEastEnders' Big Mo are brother and sister. 
    
    But do you know these other celeb family ties… https://t.co/dtzMwD3nBB
    Tweet 67: RT @BBCOne: .@NiallOfficial won't let fame get to his head - Ireland won't allow it. 
    
    Happy #StPatricksDay 🍀 https://t.co/OrWR94HStF
    Tweet 68: ♻️🗑 This shop encourages you to bring your own container from home to save on single-use plastic waste. https://t.co/TdHJSycKtO
    Tweet 69: 🇮🇪 🍀 Celebrate #StPatricksDay in true Irish style with these delicious recipes! 👉https://t.co/2MCMlz6K0B https://t.co/k18P3Syx2N
    Tweet 70: From scrambled eggs to chilli-spiced crisps: here are six great ways to cook with kale. 😋👉https://t.co/lqKD1h83Iv https://t.co/yWESBJm62q
    Tweet 71: RT @BBCTwo: Happy #StPatricksDay! Check out what's lurking beneath the calm waters of Ireland's west coast... 🇮🇪🦈 https://t.co/6MQgyLTlIr
    Tweet 72: 🎶🐦 Did you know that bullfinches can learn to sing a tune by mimicking humans?
    
    🔊 Sound on for this one!  https://t.co/44OFulioZp
    Tweet 73: RT @BBCEngland: Stephen Hawking's PhD thesis has been viewed 250,000 times online since news of his death broke on Wednesday, the Universit…
    Tweet 74: Ready to get active?
    🏃 Here are 5 ways you can get involved in #SportRelief2018. 
    👉 https://t.co/wmKUWBDBjp https://t.co/xr7g5Hw4PK
    Tweet 75: RT @BBCR1: This guy just raised over a million pounds for @sportrelief 🙌🏻
    
    Congratulations on completing a truly mammoth task @gregjames, w…
    Tweet 76: 💪😲⚽️ Keepy-uppy the good work! https://t.co/lFtKEBxjNJ
    Tweet 77: ❤️🎧 Bradley has never let Asperger's hold him back from doing what he loves. https://t.co/5JFvIXeDSZ
    Tweet 78: Running for the door on a Friday afternoon like...
    #FridayFeeling https://t.co/optoQcK1TV
    Tweet 79: 🔊🎵Jarvis Cocker describes the dream-like experience of visiting La Monte Young's Dreamhouse.… https://t.co/O9u7sPRL5m
    Tweet 80: RT @BBCR1: The gruelling task of climbing Ben Nevis in underway for @gregjames after cycling 180 miles in a day and a half!
    
    Don't know abo…
    Tweet 81: Prepare to get that warm fuzzy feeling - the man who photobombed his wife 11 years before he met her:… https://t.co/iZBJ8dEKhz
    Tweet 82: 🤔🎨 Why are soap bubbles such gorgeous colours? https://t.co/ppaXTcvWRZ
    Tweet 83: RT @BBCNewsPR: Get ready to make the headlines. 
    
    Try out our new BBC iReporter game, putting you in the heart of the newsroom #BBCSchoolRe…
    Tweet 84: 😂 Fights, funerals, and giant furry heads... @BBCThree lifts the lid on the lives of English football's mascots
    👉… https://t.co/gEYxoetlah
    Tweet 85: RT @BBCRadio2: It's with a heavy heart that today we announce, after 18 fantastic years, @realLynnBowles is leaving Radio 2. 😢
    
    @realkenbru…
    Tweet 86: Are you getting enough sleep? This simple test will tell you... 🥄😴#WorldSleepDay https://t.co/SP28dsdLSf
    Tweet 87: RT @bbcthree: the dancing in taylor swift's new video seems pretty familiar 
    
    CC @ChrisLilley https://t.co/MfA9usnqSb
    Tweet 88: RT @BBCEngland: Oscar-winning British short film The Silent Child is to be shown on BBC One on Good Friday, giving UK viewers the first cha…
    Tweet 89: RT @BBCScotlandNews: Meet Chloe - the five-year-old girl changing perceptions of Down's syndrome https://t.co/UNylRgDoY0 https://t.co/4ZjpI…
    Tweet 90: RT @BBCWales: 🌼 Daffodils dance in the spring sunshine above Tenby harbour
    
    📷 #Photooftheday » https://t.co/kNBVDzoYrZ https://t.co/OEQQWR7…
    Tweet 91: 💪 After having his leg amputated, @MarkSmithBB is now training to become the world's strongest disabled man. https://t.co/BXlGp09hya
    Tweet 92: 🌸🌻🌺
    Take a look at some of the strangest, scariest and most wonderful plants on the planet, and find out what makes… https://t.co/AMFIAuRcxW
    Tweet 93: 😬🛰🌏 Brace yourselves... a Chinese space station could be about to crash into earth. https://t.co/cPFxyUhRsq
    Tweet 94: Why were Ansel Adams photographs of America so important? #Civilisations https://t.co/8krOMxDz9C
    Tweet 95: At a time in China when artists were persecuted, this painter secretly created beautiful landscapes. #Civilisations https://t.co/ApGgOkXX2w
    Tweet 96: 70% of children growing up in poverty in Scotland have a parent who is in work. https://t.co/NPY8FbCaf4
    Tweet 97: No time in the mornings? 
    🍯🍎 Pop these in the fridge the night before to feed the family breakfast almost instantly… https://t.co/FtuewpoBva
    Tweet 98: 🎨🖼️ Meet the amazing 84-year-old who’s never had an art lesson but painted a life-size replica of a Canaletto maste… https://t.co/X39YxKuxKe
    Tweet 99: RT @BBCR1: .@CHVRCHES covering @The1975's 'Somebody Else' in the Live Lounge is so stunning 🌹 https://t.co/djNHaPKlLi
    Tweet 100: Tiny cookery. It's like regular cookery, but smaller. https://t.co/9Q0R2CiUVi
    Tweet 101: RT @YandR_CBS: Forever evolving, Forever inspiring, Forever Young and Restless. ❤️ Get ready to celebrate 45 years of #YR starting in just…
    Tweet 102: New start times in East/Central Time Zones: #60Minutes 7:37ET/6:37CT #Instinct series premiere 8:37ET/7:37CT… https://t.co/xT3YKqmu2M
    Tweet 103: Spend your Sunday streaming Second Round games LIVE with a FREE trial of CBS All Access! https://t.co/3P85rXLy4b https://t.co/zbWfirD9Ju
    Tweet 104: RT @instinctcbs: TONIGHT, Dr. Dylan Reinhart rewrites the book on abnormal behavior. Don't miss the premiere of #Instinct at 8/7c! https://…
    Tweet 105: If any duo knows how to rock the stage, it's @FLAGALine. The Vocal Duo Of The Year nominee will perform live at the… https://t.co/FknabB8NQp
    Tweet 106: How is your bracket looking after last night? Stream Second Round games LIVE today with a FREE trial of CBS All Acc… https://t.co/25JlIpgwog
    Tweet 107: Where better to spend #StPatricksDay than the place everybody knows your name? It’s just your luck that every singl… https://t.co/Fom5wmdENL
    Tweet 108: Stars @JakeMcDorman and Nik Dodani will join the cast in the upcoming revival of Murphy Brown coming to CBS.… https://t.co/JCAx29lo0i
    Tweet 109: RT @thegoodfight: Go behind the scenes with costume designer @DanLawsonStyle in "Behind The Style," a new weekly video series all about the…
    Tweet 110: The games have just begun! Continue to stream First Round games LIVE today with a FREE trial of CBS All Access:… https://t.co/YTGsJ48zYP
    Tweet 111: RT @TheTalkCBS: You asked, we answered! The fun never ends when the ladies #KeepTalking and answer your fan questions 🗣💬➡️ https://t.co/ie1…
    Tweet 112: RT @instinctcbs: Dr. Dylan Reinhart is lured back into the field from his life of quiet academia when a certain serial killer makes things…
    Tweet 113: Stream First Round games LIVE today starting at 12PM ET with a FREE trial of CBS All Access! https://t.co/3P85rXLy4b https://t.co/vZow3YD8cb
    Tweet 114: RT @CBSSports: It's the most wonderful time of the year. #MarchMadness https://t.co/e4c9qohqSR
    Tweet 115: Give these ladies some love! @Lauren_Alaina, @DBradbery, @carlypearce, and @RaeLynn are nominated for New Female Vo… https://t.co/IVhwURfJ3S
    Tweet 116: RT @ManWithAPlan: Hungry for more #ManWithAPlan bloopers and behind-the-scenes videos featuring cast like @matt_leblanc, @thelizasnyder, @k…
    Tweet 117: Music stars @MileyCyrus, @edsheeran, @ladygaga, and more will honor the legendary @eltonofficial and his hit songs… https://t.co/UzxARCCLnI
    Tweet 118: RT @thegoodfight: The verdict is in. The new season of #TheGoodFight is 🔥🔥🔥! Stream it now on CBS All Access: https://t.co/FkYSNSXlRb https…
    Tweet 119: RT @MadamSecretary: In less than an hour, #MadamSecretary's Keith Carradine will be taking over the @MadamSecretary Twitter page! Tweet alo…
    Tweet 120: RT @DierksBentley: Take and post a photo of the woman in your life who inspires you daily! Use the hashtag #WomanAmenACM in your post for a…
    Tweet 121: RT @MomCBS: If you missed guest star @KChenoweth in the latest episode of #Mom, not to worry! Watch now: https://t.co/RlvXoGOZ0l https://t.…
    Tweet 122: Give a round of applause to @KelseaBallerini, @MirandaLambert, @Reba, @MarenMorris, and @CarrieUnderwood, the five… https://t.co/Ncp1BTXx6N
    Tweet 123: RT @thegoodfight: Smart, sexy, and sophisticated. See what's coming this season on #TheGoodFight. https://t.co/CuKhx2G50P https://t.co/ygTI…
    Tweet 124: RT @BlueBloods_CBS: Even stand-up guys fall down sometimes. #BlueBloods is new tonight at 10/9c! https://t.co/UOlDm22wWW
    Tweet 125: Today and every day we celebrate the women in our lives who empower and inspire us. Share a story about an influent… https://t.co/9rVtqrElvT
    Tweet 126: Take and post a photo of the woman in your life who inspires you daily! Use the hashtag #WomanAmenACM in your post… https://t.co/7ShhvE48zy
    Tweet 127: RT @thegoodfight: Meticulously constructed. Soapy &amp; sexy. Intoxicating, savage television. 🔥 Here's what critics are saying about #TheGoodF…
    Tweet 128: This just in! @Jason_Aldean, @mirandalambert, @LukeBryanOnline, and many more are set to perform at the 53rd Academ… https://t.co/mfxw2VxzU4
    Tweet 129: Meet the ensemble of talented actors slated to join $1, a new mystery series coming to CBS All Access:… https://t.co/QoyYv7vxwg
    Tweet 130: Will @Jason_Aldean, @garthbrooks, @LukeBryanOnline, @ChrisStapleton, or @KeithUrban be named Entertainer Of The Yea… https://t.co/rMD8zjeX3s
    Tweet 131: RT @thegoodfight: It feels good to be back. 👠💄🔥 The season 2 premiere of #TheGoodFight is now streaming, exclusively on CBS All Access: htt…
    Tweet 132: RT @thegoodfight: Tomorrow, #TheGoodFight is back. Stream the season 2 premiere only on CBS All Access: https://t.co/tNFR8LBJO2 https://t.c…
    Tweet 133: Who are the trailblazing women in your life that inspire you? Join CBS and the ANA's #SeeHer initiative, celebratin… https://t.co/M0KqZ41Bes
    Tweet 134: Join @maria_bello, @aishatyler and @TeaLeoni in celebrating the accomplishments of women who have contributed to th… https://t.co/MefESBeFL3
    Tweet 135: In honor of Women's History Month, CBS and the Association of National Advertisers' (ANA) #SeeHer initiative will p… https://t.co/2wtYxKJVuO
    Tweet 136: RT @ZoeListerJones: Tonight’s an all new Life In Pieces and it’s directed by my ride or die @nataliaanderson!!!… https://t.co/2LPfmyLWrY
    Tweet 137: RT @MarenMorris: Hot damn! Woke up from my post-wisdom teeth haze to find out I’m up for 4 @ACMawards ! So honored, especially for the Dear…
    Tweet 138: RT @KelseaBallerini: Ohhhhh goodness. Incredible. Thank you thank you thank you. #female https://t.co/1ZTYjNfQeF
    Tweet 139: RT @KeithUrban: ACMs...... HOLY SMOKES!!!!! MAD LOVE TO U ALL THIS MORNING  FOR THESE INCREDIBLE NOMINATIONS. I’M EXTREMELY GRATEFUL!!!!!!!…
    Tweet 140: RT @ACMawards: Congratulations to this year’s #ACMawards Video of the Year nominees:
    “Black” - @DierksBentley
    “It Ain’t My Fault” - @Brothe…
    Tweet 141: RT @ACMawards: Please give a round of applause to this year’s #ACMawards Entertainer of the Year nominees: @Jason_Aldean, @GarthBrooks, @Lu…
    Tweet 142: .@ChrisStapleton, @ThomasRhett, @mirandalambert and more are all nominated for awards at Country Music's Party of t… https://t.co/Vm1vXRUDYJ
    Tweet 143: The Queen of Country, @Reba, is returning to host the 53rd #ACMawards on Sunday, April 15 at 8/7c. Here are a few o… https://t.co/Iqzz6Gql01
    Tweet 144: RT @survivorcbs: It’s time! #Survivor https://t.co/YPk6cGWrUA
    Tweet 145: RT @CBSThisMorning: TOMORROW: The nominees for the 2018 @ACMawards will be announced live by the one-and-only, @Reba! 
    
    Watch on @CBS in ou…
    Tweet 146: RT @thegoodfight: From the set design and costumes to hair and makeup, the production quality is truly next-level. Take a peek inside the u…
    Tweet 147: RT @LivinBiblically: The fun continues on Facebook! The #LivingBiblically cast is live to talk about tonight’s premiere. Tune in here: http…
    Tweet 148: RT @KevinCanWaitCBS: Can you get all the way through these #KevinCanWait bloopers without laughing?! @KevinJames,@LeahRemini and the rest o…
    Tweet 149: RT @ACMawards: That’s right! @Reba is headed to @CBSThisMorning on Thursday, March 1 to announce this year’s #ACMAwards' nominees. Tune in…
    Tweet 150: RT @ScorpionCBS: You can't hack your way to a 197 IQ, but you are well on your way with these Genius Facts from #TeamScorpion! 💻 You can be…
    Tweet 151: RT @SuperiorDonuts: You can always count on @DavidKoechner for a laugh! Did your favorite Tush moment make the list? Catch a new #SuperiorD…
    Tweet 152: RT @TheTalkCBS: TODAY: We loved them together then &amp; we love seeing them together now! Welcome back to the show @THESaraGilbert​'s good fri…
    Tweet 153: RT @thegoodfight: As foundations begin to crumble, our characters struggle to make sense of this new dystopian world. The cast teases what'…
    Tweet 154: #LivingBiblically's @linzkraft and @jrfergjr appeared on @KCBS's Facebook Live this morning, talking all about what… https://t.co/4RebcHuuMQ
    Tweet 155: RT @CBSSports: Introducing CBS Sports HQ, a New 24/7 Direct-to-Consumer Streaming Network for Sports News, Highlights, &amp; Analysis.
    
    Stream…
    Tweet 156: RT @CBSBigBrother: It’s down to the final 5 celebrity Houseguests, and anyone could take home the grand prize! Tune in NOW to watch the #BB…
    Tweet 157: RT @startrekcbs: Binge the entire first season of #StarTrekDiscovery. All episodes now streaming exclusively on CBS All Access: https://t.c…
    Tweet 158: RT @thegoodfight: #TheGoodFight returns in 1 week. Season 2 premieres Sunday, March 4. https://t.co/nomCao1GWp https://t.co/BOn6bOe9Tb
    Tweet 159: RT @thegoodfight: This is our new favorite thing. Christine Baranski debuted #TheGoodFight the Musical on @colbertlateshow last night! 🎵🎤…
    Tweet 160: RT @LivinBiblically: Confession time: have YOU ever hit the "close door" button in an elevator while somebody was approaching? The cast of…
    Tweet 161: RT @CBSEyeSpeak: Mark your calendars! #CBSEyeSpeak kicks off March 14 with The EYE Speak Summit. Follow our page for more details! https://…
    Tweet 162: RT @CBSEyeSpeak: Proud to announce a new CBS initiative, promoting female empowerment and developing the next generation of leaders through…
    Tweet 163: RT @LivinBiblically: When you're living by the Bible, it's good to have a priest and a rabbi on call (provided they answer their phones, th…
    Tweet 164: RT @thegoodfight: Chicago lawyers are being hunted and the world is going insane. 
    
    The new season of #TheGoodFight premieres Sunday, March…
    Tweet 165: Ready for some larger than life competition? This new series from @MarkBurnettTV will premiere in summer 2018.… https://t.co/gDXHLdIJ5v
    Tweet 166: With tournament dreams on the line, make sure to stream these college basketball matchups on CBS All Access:… https://t.co/SGkYUZrQWB
    Tweet 167: RT @LivinBiblically: While Chip's sticking to the Bible's original rules, the cast of #LivingBiblically has given them a more modern makeov…
    Tweet 168: Casting News! Peter Mark Kendall, Michael Gaston, Greg Wise, Rade Šerbedžija, Zack Pearlman, and Keye Chen join the… https://t.co/GFob2KrD8H
    Tweet 169: RT @BullCBS: The verdict is in...#Bull is the perfect Valentine! ❤️ Happy #ValentinesDay! https://t.co/poEejI4AnC
    Tweet 170: RT @NoActivityCBS: Car 27 reporting: Season 2 of #NoActivity coming soon!
    
    Binge season one now on CBS All Access: https://t.co/yvxoQMeyhN…
    Tweet 171: RT @LivinBiblically: Against all odds (and the advice of his God Squad), Chip is determined to live life by the Good Book. Think you could…
    Tweet 172: RT @thegoodfight: Christine Baranski reflects upon the spectacular metamorphosis of her character in #TheGoodFight's first season. Revisit…
    Tweet 173: RT @startrekcbs: Binge the entire first season of #StarTrekDiscovery. All 15 episodes now streaming on CBS All Access: https://t.co/lKLaptP…
    Tweet 174: RT @SuperiorDonuts: Looking for a #Valentine? Tush is here to help you land your dream date just in time for the day of love! #SuperiorDonu…
    Tweet 175: RT @CBSBigBrother: The pressure is on as the Houseguests battle each other for victory in the first HOH competition. Stream the season prem…
    Tweet 176: RT @startrekcbs: Sunday, this season's epic journey reaches its final reckoning. Catch up before the season finale: https://t.co/4Ea5wpmAep…
    Tweet 177: Are you a sucker for jaw-dropping talent competitions? Announcing The World's Best, a first-of-its-kind new global… https://t.co/fagCMklm2Z
    Tweet 178: RT @BullCBS: Tonight, one of these 3 TAC employees will end up incarcerated. Who do you think it will be? Tune into a new episode of #Bull…
    Tweet 179: RT @thegoodfight: There's no season like lawyer season. #TheGoodFight returns March 4, exclusively on CBS All Access. https://t.co/XAlrg1nB…
    Tweet 180: RT @thegoodfight: The acclaimed series returns in 1 month. #TheGoodFight is back Sunday, March 4. https://t.co/5BNLTYRd8p https://t.co/yInP…
    Tweet 181: .@KeshaRose's emotional performance with @CyndiLauper, @AndraDayMusic, @BebeRexha and @Camila_Cabello brought the a… https://t.co/qpgS2e9ir0
    Tweet 182: Broadway legend Patti LuPone paid tribute to Sir Andrew Lloyd Webber with a show-stopping rendition of the iconic s… https://t.co/GxqLtUzhFP
    Tweet 183: Relive an entire night's worth of big wins, live performances and many more inspiring moments from The 60th Annual… https://t.co/CH7mJ4Y3QT
    Tweet 184: RT @swatcbs: ✨@TheTalkCBS' @TheRealEve and @ShemarMoore brought some serious heat to the GRAMMYs red carpet: https://t.co/WYTITKkLQd https:…
    Tweet 185: The all-star collaboration between @Rihanna, @DJKhaled and @brysontiller brought the party to the #GRAMMYs with a s… https://t.co/jTv5QbtgUp
    Tweet 186: RT @TheTalkCBS: All the #redcarpet looks from the 60th annual #GRAMMYs! Did you catch @TheRealEve's sparkly two-piece suit? Diamond accents…
    Tweet 187: Go backstage with the celebs and see which stars celebrated the big night together! Here are the moments you missed… https://t.co/rgQTXRQyLg
    Tweet 188: 🎶 @DearEvanHansen star Ben Platt gave a soaring performance of a classic Broadway hit. Watch him perform 'Somewhere… https://t.co/HcuizFWo02
    Tweet 189: 🎸 @LittleBigTown, @U2, @BrunoMars and @Pink are just a few of the superstar performers that lit up the stage at The… https://t.co/2v0MNYMItG
    Tweet 190: Don't miss country stars Emmylou Harris and @ChrisStapleton perform a moving rendition of @TomPetty's classic song,… https://t.co/GxoIW97XIu
    Tweet 191: RT @survivorcbs: Get excited! 🙌 It’s finally time to meet the castaways of #Survivor: Ghost Island ☠ https://t.co/xQQ8ROhKbM https://t.co/P…
    Tweet 192: Country stars @EricChurch, @BrothersOsborne and @MarenMorris performed a touching tribute dedicated to the victims… https://t.co/YCIq9i70fd
    Tweet 193: Missed the Man vs. Beast #SuperBowlCommercials showdown? Catch up now to find out which entertaining ad was named t… https://t.co/SlyO0n7yMX
    Tweet 194: RT @rikimae: Ok, that one makes me cry #superbowlcommercials
    Tweet 195: If this doesn’t make you cry, nothing will. #SuperBowlCommercials https://t.co/UjFf3xr4so
    Tweet 196: RT @maverickkr: #superbowlcommercials the frogs were great, I'd forgotten about that one.
    Tweet 197: If you haven't voted yet, it's not too late! Choose your favorite here: https://t.co/s4pEIF5IX8… https://t.co/VCa1YHDyYy
    Tweet 198: RT @5691e44f3b66446: I am having so much fun ...the commercials are awesome #superbowlcommercials
    Tweet 199: RT @LittleShelbyMae: Love watching the #superbowlcommercials all the animal ones are my favorite!!
    Tweet 200: RT @PatHale915: Doritos time machine was great!   #superbowlcommercials
    Tweet 201: US President Trump has signed an executive order banning US citizens from buying Venezuela's newly created cryptocu… https://t.co/oOwF0OTrNm
    Tweet 202: This village in China is a modern-day shrine to President Xi Jinping. CNN paid a visit and were followed by securit… https://t.co/CFX3QycJcJ
    Tweet 203: "All acts and tricks to split the motherland are doomed to failure and will be condemned by the people and punished… https://t.co/oD9PrLELgu
    Tweet 204: Delta Airlines misrouted an Idaho man's 8-week-old puppy on a cross-country trip -- landing in Las Vegas and Salt L… https://t.co/FOkdT3e1Y7
    Tweet 205: Neanderthals, Denisovans and our ancestors were mixing and mingling a long time ago -- and some of our genetics can… https://t.co/VkXGPKzK9N
    Tweet 206: The Cambridge Analytica scandal has done immense damage to the Facebook brand, sources across the company believe… https://t.co/EjcHYYvul9
    Tweet 207: Facebook's value plunges $37 billion on news that data firm Cambridge Analytica, which had ties to Trump's campaign… https://t.co/2N2l7AoNZ7
    Tweet 208: Patients who visit emergency rooms are getting hit with sky-high bills. Spending on an ER visit in the US rose to $… https://t.co/1TvD7xi3ZD
    Tweet 209: How a designer got his scarf into "Black Panther" https://t.co/PZFJ6EQBGX https://t.co/5afeV6hll3
    Tweet 210: This single mother and her four children were living out of their car. Then a cop decided he had to do something.… https://t.co/OHbvJtH2mU
    Tweet 211: The US announces the start date for its annual military exercises with South Korea as President Trump readies for a… https://t.co/XhKwzBWxnI
    Tweet 212: Correction: This story has been updated to clarify that Sudan was a northern white rhino. https://t.co/sxb8eAeKcT https://t.co/3IAFpojlJK
    Tweet 213: The world's last male white rhino has died leaving only two females left to save the species from extinction.… https://t.co/mN92F0nLwL
    Tweet 214: 9/11 hero who saved hundreds dies of cancer at age 45 https://t.co/RsYz8zDVX4 https://t.co/eAW7TRsPyD
    Tweet 215: Amnesty International has accused the Nigerian army of failing to act on "advance warnings" given a few hours befor… https://t.co/OzUer6y6xw
    Tweet 216: Undercover British television report is "edited and scripted to grossly misrepresent the nature of those conversati… https://t.co/DQbCb3eF1W
    Tweet 217: President Trump has signed an executive order banning US citizens from buying Venezuela's newly created cryptocurre… https://t.co/atpoLD928t
    Tweet 218: A military band plays out the delegates in the Great Hall of the People, ending the 13th National People's Congress… https://t.co/kpJXcbpoep
    Tweet 219: Your personal information is Facebook's currency. It's bought and sold every day. https://t.co/6s4nc2UgOs
    Tweet 220: "All acts and tricks to split the motherland are doomed to failure and will be condemned by the people and punished… https://t.co/MbjE8JbxyM
    Tweet 221: "Trump is Nixon on steroids and stilts."
    
    John Dean, who served as White House counsel for President Richard Nixon… https://t.co/BwMCukpgiN
    Tweet 222: Six months after Hurricane Maria devastated Puerto Rico, the news is the return of normalcy for some. But the road… https://t.co/EqmCCIZ98P
    Tweet 223: In 1999, there were more than 2 million pay phones across America. 100,000 are left today. https://t.co/YhVnkog7mu https://t.co/RdQyhgYJMW
    Tweet 224: (Correction) Ballerina Misty Copeland made history in 2015, becoming the 1st female African American principal danc… https://t.co/KX0wCvTVZ6
    Tweet 225: The Cambridge Analytica scandal has done immense damage to the Facebook brand, sources across the company believe… https://t.co/DdqhcY78x9
    Tweet 226: 96-year-old style icon Iris Apfel has become the oldest person ever to be immortalized as a Barbie doll… https://t.co/6dOW9LLZfx
    Tweet 227: Speaking at the closure of the 13th National People's Congress, Chinese President Xi Jinping delivered a confident,… https://t.co/OxfcUDYKkw
    Tweet 228: "President Trump is acting guilty as hell going after Mueller," says Democratic Sen. Chris Van Hollen… https://t.co/beD34Po0QU
    Tweet 229: The studio co-founded by disgraced movie mogul Harvey Weinstein has been crippled by the sexual harassment and assa… https://t.co/gKN3STMjVu
    Tweet 230: This village in China is a modern-day shrine to President Xi Jinping. CNN paid a visit and were followed by securit… https://t.co/A1HvaNuj8B
    Tweet 231: A 9-year-old boy retrieved a gun from his parents' bedroom and shot his 13-year-old sister to death after the two g… https://t.co/1CXndSSZuE
    Tweet 232: Ballerina Misty Copeland made history in 2015, becoming the first principal dancer for American Ballet Theatre. We’… https://t.co/kuuodA3nas
    Tweet 233: Mississippi Gov. Phil Bryant has signed into law a bill that prevents women from getting abortions after 15 weeks o… https://t.co/VILPjdWHhz
    Tweet 234: Susan Pompeo, wife of CIA chief Mike Pompeo, has taken on an unusually active role for a CIA spouse in agency affai… https://t.co/kCo2Mh2rkR
    Tweet 235: Wylie discusses Cambridge Analytica's possible connections to Russia: “I am concerned we made Russia aware of the p… https://t.co/zJnKlQkUQJ
    Tweet 236: How a designer got his scarf into "Black Panther" https://t.co/vIjG20TbWu https://t.co/GDD5ibMslm
    Tweet 237: “Facebook’s only doing something now because I am coming out and speaking out.” Wylie says he is frustrated with th… https://t.co/w9a7vSaOAc
    Tweet 238: Wylie says Cambridge Analytica had tested Trump campaign slogans since 2014: "I was surprised when I saw the Trump… https://t.co/a8PZRMDTnx
    Tweet 239: Why Mark Zuckerberg needs to testify before Congress | By Kara Alaimo via @CNNOpinion https://t.co/xdgtqjnNK6 https://t.co/QGVEi85ce1
    Tweet 240: Former Cambridge Analytica contractor Christopher Wylie tells CNN’s @donlemon that he helped build a “psychological… https://t.co/uzQAgripRy
    Tweet 241: A 19-year-old US student who went missing over the weekend has been found dead in Bermuda, authorities there say… https://t.co/ZBGYwmmQQt
    Tweet 242: Delta Airlines misrouted an Idaho man's 8-week-old puppy on a cross-country trip -- landing in Las Vegas and Salt L… https://t.co/4xzHQ2OpOQ
    Tweet 243: As President Trump's reaction to special counsel Robert Mueller grows more irate by the day, attorneys on both side… https://t.co/PAGvAKksV2
    Tweet 244: The US announces the start date for its annual military exercises with South Korea as President Trump readies for a… https://t.co/3fNnGF2WTM
    Tweet 245: A Marjory Stoneman Douglas graduate is making a sculpture to honor the school shooting victims. The names of the "1… https://t.co/OGSqWoxYD0
    Tweet 246: RT @AC360: Republican Rep. Matt Gaetz says Attorney General Jeff Sessions would be "right to renounce his recusal, to re-establish command…
    Tweet 247: Facebook's value plunges $37 billion on news that data firm Cambridge Analytica, which had ties to Trump's campaign… https://t.co/VTPrmyYTEc
    Tweet 248: It's official: "Sex and the City" star Cynthia Nixon has announced that she is throwing her hat in the New York gub… https://t.co/Dy0HfIgbQI
    Tweet 249: RT @AC360: Anderson Cooper: President Trump's recent actions aimed at undermining the institutions that he believes threaten him is a patte…
    Tweet 250: Alex Stamos, Facebook's chief security officer, says he's still "fully engaged" in his work at Facebook following r… https://t.co/ArNf1dJY7L
    Tweet 251: RT @OutFrontCNN: Comedian John Oliver, Vice President Mike Pence, a pair of bunny books, and one "hopping mad" publisher. This is the tale…
    Tweet 252: The NTSB wants the FAA to ban commercial flights' use of harness systems that don't allow for easy release during e… https://t.co/W2wiBEX3Vd
    Tweet 253: First lady Melania Trump made a rare appearance that included public remarks in support of those battling the opioi… https://t.co/wIYSztOJIm
    Tweet 254: The spending bill that Congress is expected to usher though this week will most likely not include sexual harassmen… https://t.co/cwWMuYOKWS
    Tweet 255: Former Nixon White House counsel John Dean says President Trump "is Nixon on steroids and stilts"… https://t.co/IsKq3WBVCi
    Tweet 256: A load of gold worth up to $54 million went missing during the Civil War. The mystery gained new life when FBI agen… https://t.co/dKZAFdBUx0
    Tweet 257: Power, sex and data: A weekend of issues in the Trump presidency | By Juliette Kayyem via @CNNOpinion… https://t.co/Luhz309KQn
    Tweet 258: El Salvador may be the first country to have a community of 3D-printed homes https://t.co/zn5VfEuBWP https://t.co/vkdtHpla2L
    Tweet 259: "What I think we're witnessing is a very public obstruction of justice. He ... has already exceeded everything that… https://t.co/XuIPoigeJw
    Tweet 260: Democratic Rep. Jim Himes on President Trump adding attorney who pushed theory DOJ framed Trump: "He is looking for… https://t.co/uADfABs9wF
    Tweet 261: It's one thing to have a situation where Facebook may be targeting users with ads; It's a different situation when… https://t.co/rCEnSB20ua
    Tweet 262: We ignore these Iraq War lessons at our peril | By Jeremi Suri via @CNNOpinion https://t.co/PTI4pEW3sq https://t.co/uR8N5s2f3X
    Tweet 263: Why Senate Majority Leader Mitch McConnell hasn't said anything about President Trump's attacks on special counsel… https://t.co/pMIYW3co5R
    Tweet 264: A billionaire, a Kennedy and an upstart state lawmaker are the leading Democratic challengers in the race to unseat… https://t.co/dlyGsPvxkO
    Tweet 265: The US warned that ISIS has begun reconstituting in some areas of Syria because a Turkish military offensive agains… https://t.co/ZnonenOhTJ
    Tweet 266: President Trump called the Russia investigation a "total witch hunt." @jaketapper takes a closer look at recent dev… https://t.co/PeCjjSdiJE
    Tweet 267: Your personal information is Facebook's currency. It's bought and sold every day. https://t.co/n2ijDvNtBB
    Tweet 268: The wife of the man who killed dozens at an Orlando nightclub in 2016 told FBI investigators she knew beforehand th… https://t.co/5SuIBNH0k4
    Tweet 269: President Trump, who as a candidate used the Clinton Foundation to slam his opponent Hillary Clinton, heralded an o… https://t.co/rGpaIWkWkV
    Tweet 270: Three members of the Congressional Black Caucus have called for the bombings in Austin, Texas, to be classified as… https://t.co/NlFGxAz2WZ
    Tweet 271: A school resource officer initially recommended involuntarily committing the Florida school shooter over mental hea… https://t.co/fH7Jmsnr24
    Tweet 272: RT @TheLeadCNN: The special counsel’s investigation is hardly a witch hunt. It has:
    ➡️ Yielded charges against 19 people and 3 companies, s…
    Tweet 273: "This is not their favorite topic." -Sen. Sheldon Whitehouse on Republican lawmakers being forced to field question… https://t.co/7kKARERij9
    Tweet 274: It's winter's last day, and about 20M are in the path of severe storms as large hail and damaging winds hit parts o… https://t.co/kcv5meTlKL
    Tweet 275: The Cambridge Analytica scandal has done immense damage to the Facebook brand, sources across the company believe… https://t.co/k32dEHDbfS
    Tweet 276: RT @TheLeadCNN: We're celebrating 5 years of #TheLead with @jaketapper! Thank you to all of our viewers for watching! 📺 https://t.co/3NmZOk…
    Tweet 277: Trump lawyer Michael Cohen jokes about Stormy Daniels, saying he might take "an extended vacation on her dime"; A l… https://t.co/pTf3j0iLUk
    Tweet 278: With just days before a potential shutdown, negotiations continue on a must-pass spending bill… https://t.co/qmINUShnrI
    Tweet 279: An anti-abortion, conservative Democrat fights for survival in the Illinois primary https://t.co/IsSkwVA69D https://t.co/3Nv9Gdt00P
    Tweet 280: What you need to know about Facebook's data debacle https://t.co/ngPqheWSSq https://t.co/G7X2Inay7b
    Tweet 281: The Supreme Court just gave Democrats a much better chance of retaking the House in 2018 | Analysis by @CillizzaCNN… https://t.co/ENTEP3LgMq
    Tweet 282: Republicans are bluntly warning President Trump to lay off his attacks on special counsel Robert Mueller, but there… https://t.co/lBBpwb5d1E
    Tweet 283: President Trump's lawyers recently provided the special counsel's office with documents in an attempt to limit the… https://t.co/hvD3zJposE
    Tweet 284: Senator Warner says it was "more than a little bit fishy" that former FBI Deputy Director Andrew McCabe was fired 3… https://t.co/ZD7Fqa0RWu
    Tweet 285: RT @CNNSitRoom: Facebook is under intense pressure to answer questions after it admitted that a company linked to President Trump's campaig…
    Tweet 286: Rep. Adam Schiff on Trump attacking special counsel Robert Mueller on Twitter: The President seems to be testing th… https://t.co/fkEcFAG4M8
    Tweet 287: RT @TheLeadCNN: "What you have is like the ‘Survivor’ meets ‘The Apprentice’ meets ‘Game of Thrones.’ It is the most insane scenario ... th…
    Tweet 288: Sen. Jeanne Shaheen: If President Trump has nothing to hide, then he should be interested in seeing this investigat… https://t.co/CwcznrIfm2
    Tweet 289: Sen. Jeanne Shaheen: I’ve been disappointed more Republican lawmakers aren’t speaking out to protect special counse… https://t.co/FQIXvLkvWF
    Tweet 290: Sen. Jeanne Shaheen: I’ve been disappointed more Republican lawmakers aren’t speaking out to protect special counse… https://t.co/4XVMG61Kt0
    Tweet 291: "[Trump] has been extremely consistent. He hates this investigation," and "he is scared of this investigation." - T… https://t.co/DzZka7zHAD
    Tweet 292: RT @TheLeadCNN: Austin, Texas authorities say the 4th bomb that went off overnight is the most sophisticated yet https://t.co/uqdA06osou ht…
    Tweet 293: US President Trump has yet to congratulate Russian President Vladimir Putin on his election, and a phone call betwe… https://t.co/WclI7Tljht
    Tweet 294: Uber has removed its self-driving cars from the road after a self-driving Uber SUV struck and killed a pedestrian i… https://t.co/gODSZocjLN
    Tweet 295: Authorities are speaking in Tempe, Arizona, about the self-driving Uber SUV that struck and killed a woman. Watch o… https://t.co/2WJR68WqSC
    Tweet 296: At least four people have died following head-on crashes in Hyundai and Kia cars in which the airbags did not deplo… https://t.co/NYc6ZPBVDp
    Tweet 297: The Turpin siblings, allegedly tortured for years by their parents, are out of hospitals but still regularly in tou… https://t.co/KyDF93PMYn
    Tweet 298: The Federal Reserve is all but certain to lift interest rates when Jerome Powell leads his first meeting as chairma… https://t.co/HIQRM5w4Bx
    Tweet 299: Opponents of abortion will come to the Supreme Court on Tuesday to challenge a California law they say is an uncons… https://t.co/3m0Rs9PvG4
    Tweet 300: Facebook sinks nearly 7% as the user data controversy sparks the company's worst day in four years.… https://t.co/uAmoZ6NeSv
    Tweet 301: @butwhoiskat thank you!
    Tweet 302: Here it goes. Last 8 months of constant work will happen within the next 3 days.
    
    https://t.co/c48sQqdnXv
    Tweet 303: RT @cssconfau: Guess what?
    
    Even if you aren’t here, you can watch all the talks LIVE! 😱
    
    Tune into the live stream here. #cssconfau18 
    
    ht…
    Tweet 304: @amyngyn hahaha. I actually never been, but I’ve heard the bar is great. :)
    Tweet 305: @amyngyn Loui Bar?
    Tweet 306: RT @LJKenward: Hey friends! 👋 Who's hiring Junior Devs at the moment? I have some awesome people from the @juniordev_io Community currently…
    Tweet 307: Don’t forget about the Community Social today! EVERYONE IS WELCOME (even if you don’t hold a CSSConf or JSConf tick… https://t.co/6c79TcKFCi
    Tweet 308: Toxic tech industry creates a fake vision of what each of us (especially minorities) have to be and achieve to be ”… https://t.co/yfXZ5nxCJ7
    Tweet 309: @amyngyn I never introduce myself. The focus is on content, not myself. Also I don’t feel like I need to justify my cred. :)
    Tweet 310: Today I got kissed by a dingo. 💁🏻‍♀️ https://t.co/FDQsVw2anl
    Tweet 311: @Sareh88 Thank you, Sareh! That’s very kind. ❤️
    Tweet 312: @meelijane https://t.co/Y5wM3nCdsH in Northcote. I’ve tested many and this one is orders of magnitude better than everywhere else. :)
    Tweet 313: One of many reasons why I love my yoga studio so much is how meditative the practice is and how all the instructors… https://t.co/VXfSqdo6bk
    Tweet 314: @IvanaMcConnell I can only help ruin your bank account further, sorry. 😂
    Tweet 315: RT @slamup: people love to say
    
         no child is born 
         with hate in their heart
    
    which is all very
    romantic
    
    but from the moment
    a bla…
    Tweet 316: @evanderkoogh Nope, we are at full capacity of the venue. :)
    Tweet 317: RT @cssconfau: Come and celebrate with us at pre CSSConf and JSConf AU community social!
    
    📅 Monday, March 19, 6pm onwards
    📍Stomping Ground…
    Tweet 318: @noahmp Heh, dang :) worth asking nonetheless.
    Tweet 319: @noahmp 👋🏻 is this a SF-based role?
    Tweet 320: RT @mbrockenbrough: Here's a point worth making every so often. The patriarchy isn't men. It's a system that prefers them. Wanting to disma…
    Tweet 321: @madalynrose Thank you so much ☺️ looking forward to meeting you! 🌺
    Tweet 322: @andymcmillan Thanks, Andy! You are an inspiration for me too! 💙
    Tweet 323: @evanderkoogh Hey Erwin! Thanks so much. We can chat during the events. :)
    Tweet 324: I don’t know what or who I’m most disappointed with to allow community work put my career in the background (again)… https://t.co/khOCa8rLHV
    Tweet 325: This time was supposed to be split between the conference and product work that would set me up for looking for a j… https://t.co/mOoFPPnV5w
    Tweet 326: Over the last 6+ months, I’ve sacrificed all the time I had to run CSSConf and JSConf AU. I’ve set the highest stan… https://t.co/QRvns2lJs8
    Tweet 327: RT @katebevan: LAYDEEZ!!!! Worried that VPNs are too hard for your fluffy ladybrain??? Never fear, a fuckwitted BroCo called @keepsafe is h…
    Tweet 328: @sarah_edo thank you! 😳
    Tweet 329: I can’t wait to come back to lovey Portland and see what wonderful thing @andymcmillan and @waxpancake are preparin… https://t.co/3rfz3ShOEU
    Tweet 330: @jennwrites thank you! I miss you too 😭❤️
    Tweet 331: To the young woman wearing a “the future is female” tee:
    
    The
    Future
    Is
    Intersectional
    Tweet 332: Cannot agree with this more. I constantly get asked for free diversity, inclusion, community or general workplace a… https://t.co/M9hOz6A980
    Tweet 333: @pat @coryannj @kckal Oh, I have not seen it. Will register. 👍🏻
    Tweet 334: Four days to go. https://t.co/RYxiCmMEFp
    Tweet 335: Ellen already had a lasting impact on diversity and inclusion spanning beyond the tech industry. 
    
    I can’t wait to… https://t.co/1QFSP6DHyQ
    Tweet 336: @jordwalsh 👋🏻 interesting! Would you be able to email me more details? hi at https://t.co/vah0lKcYeo. 📬
    Tweet 337: My last two weeks were spent in email. Conference organiser life. https://t.co/h5hlszzyjv
    Tweet 338: This video with Jeff Goldblum is everything. https://t.co/vo5HSwuOUP
    Tweet 339: Accepting talk proposals for conferences on a rolling basis: no no no no.
    
    First come first serve doesn’t work for inclusion.
    Tweet 340: If you are in Melbourne on Monday, March 19, we’re opening @cssconfau, @jsconfau and @decompressau with a Community… https://t.co/OyPVisZXYn
    Tweet 341: Australia is racist as hell. https://t.co/EIRFzejhsi
    Tweet 342: RT @sarahmei: 📢 PSA: when you're building a diverse team, you're looking for culture _add_, not culture _fit_. Hire people who bring a pers…
    Tweet 343: RT @piamancini: ok I need help. I really really want to hire a kickass developer who also happens to be a woman (backend pref.) What are th…
    Tweet 344: @piamancini Hey Pia! Thanks for reaching out 👋🏻 Unfortunately, software engineering isn’t my background; I’m a FE d… https://t.co/1IEwNKyc9q
    Tweet 345: RT @EricaJoy: 📢 PSA: There are no "diverse" applicants
    People aren't diverse, teams are
    You're not hiring a diverse person, you're building…
    Tweet 346: RT @SashaLaundy: What I keep telling myself this week: 
    👉🏻 In work, a new thing I don't know how to do means progress. 
    👉🏻 In the gym, a ha…
    Tweet 347: No underrepresented groups want to thrive and partake in exclusionary platform StackOverflow is.
    
    Tweet your hot ta… https://t.co/xfKjCfUtwJ
    Tweet 348: @erikalleigh I just block them. 😎
    Tweet 349: @jaffathecake Jake, I really admire your ability to try to have a serious conversation with inclusion deniers and mansplainers. 😂
    Tweet 350: @modernserf and thongs! I cannot grasp the diversity
    Tweet 351: @heydonworks Ohhh, this tweet so gold
    Tweet 352: RT @vaurorapub: For women in tech who need a break from talking about women in tech sometimes: here are some of the ways I get out of doing…
    Tweet 353: Do I know anyone working at @zapier?
    Tweet 354: Thank heavens for my career hotline with a few great women in tech.
    
    Sadly, we all share the same thoughts about th… https://t.co/KTzemdT7OG
    Tweet 355: I must say I’m pretty speechless. https://t.co/s4lvmWyE23
    Tweet 356: The tech industry, saving humanity from disease, poverty and injustice. https://t.co/wkmxj8c4Wy
    Tweet 357: I’m running a 4-day conference next week aka I have been listening to bird sounds on @noisli for the last eight hours.
    Tweet 358: PREACH @adblanche! 
    
    White women have a lot of homework to do. 
    
    https://t.co/PWeBC6MsXG
    Tweet 359: @brianleroux Brian, we both know that best talent lives in SF and NYC. there is no tech outside of those two regions.
    Tweet 360: @coryannj I love how the tech industry is cocky enough to believe they’re the solution to all humanity problems
    Tweet 361: ”Willing to relocate to San Francisco”. 
    
    We can’t have inclusive technology if jobs are constrained to cities whic… https://t.co/NCFLDermIF
    Tweet 362: 👋🏻 I have a bit of availability for diversity and inclusion consulting during April and May. I can help run inclusi… https://t.co/t4sbNrXUDV
    Tweet 363: RT @pangopup: 'Why sexism over how women look harms their leadership chances' https://t.co/v1YyNfpz3Z
    Tweet 364: RT @WBJenna: Have you heard about the @PineappleMedia Fellowship for Underrepresented Voices in Podcasting?
    
    -A full-time, producer-in-resi…
    Tweet 365: @coryannj Have you read Lean Out? Pretty much sums up most of my concerns with the approach. So flawed. I have a co… https://t.co/fpihGPPNkb
    Tweet 366: To be honest, all I want is a @sailorhg clothing line. https://t.co/iobZVLnosX
    Tweet 367: RT @incantatricks: Society expects women to be everything and want nothing.
    
    We have to be masters at self-improvement, conversation, emoti…
    Tweet 368: RT @ChloeCondon: Hey ladies, come work in tech. We have no bathroom lines 🚽💁🏼‍♀️ https://t.co/01stO97NKd
    Tweet 369: Friends: excited for the long weekend!
    Me: https://t.co/vPjwIGbbM4
    Tweet 370: RT @lrnrd: THIS THREAD 🍿🔥🙏🏻👏💯 https://t.co/vhfH4ETTC0
    Tweet 371: RT @ChloeCondon: Booth recruiter 🧔: ...and we really value diversity!
    
    Me 👧🏼: Do you have any women's sized shirts?
    
    🧔: Unfortunately no, t…
    Tweet 372: Amazing hosts for upcoming @CSSconfeu 💖 https://t.co/pmtGtflroP
    Tweet 373: Still wondering what companies that have less than 10% women (let alone POC) across the entire organisation (not on… https://t.co/yIyuV9WkMS
    Tweet 374: Women’s Day isn’t an arbitrary date. 
    
    It should be an ongoing celebration, empowerment and inclusion of all women… https://t.co/5EJ63WQXL6
    Tweet 375: RT @butwhoiskat: I’ll be speaking (for the first time) next Thursday, at WDYK, on the ethics of design.
    
    Wanna come support me?
    
    https://t.…
    Tweet 376: @Double_Days Hey! Unfortunately, that’s not me :)
    Tweet 377: RT @void_daddy_: the future isnt female. the future is nonbinary it's genderfluid it's queer and it's trans it's natives rising up against…
    Tweet 378: RT @soniagupta504: I'm starting to really understand the importance of psychological safety on developer teams. 
    
    With it, you have a team…
    Tweet 379: RT @vboykis: Somewhere in the multiverse, this HN exists. https://t.co/bdk0sZeucF
    Tweet 380: @ohhoe blocked because the truth was too stingy, the follow up james damore story
    Tweet 381: RT @triketora: such a useful resource for founders to be able to find the anti-harassment policies and points of contact for the vc firms t…
    Tweet 382: Hi friends! I’m looking for new opportunities to put my multidisciplinary skills to good use within a diverse organ… https://t.co/Chl7QaEgSe
    Tweet 383: @ANZ_AU You can email me at hi@thefox.is.
    Tweet 384: @Mandy_Kerr Back at you, Mandy! You’re amazing! ✨
    Tweet 385: @happycrappie thank you!
    Tweet 386: RT @shailjapatel: Read women.
    Cite women.
    Credit women.
    
    Teach women.
    Publish women.
    Present women.
    
    Acknowledge women.
    Award women.
    Amplif…
    Tweet 387: RT @EricaJoy: Men! Celebrate #InternationalWomensDay by taking direct action:
    🌟 Tell the women you work with how much you get paid.
    🌟 If yo…
    Tweet 388: Another release of @jsconfeu tickets is happening in a few minutes and you don’t want to miss out. https://t.co/MX1CYi6kiK
    Tweet 389: Everything about this—”the absence of no is not consent.”
    
    https://t.co/58usW9cFxH
    Tweet 390: Don’t try to shame me for your lack of professionalism and overconfident behaviour. 
    
    Tl:dr; don’t work for @ANZ_AU.
    Tweet 391: I told her how offensive and exclusionary those things were. Her reply:
    
    ”I'm disappointed with your interpretation… https://t.co/diQiVBdLF0
    Tweet 392: I got emailed by someone at @ANZ_AU who not only insinuated that I’m after ”fancy titles” after I said I want to dr… https://t.co/kpCyQY3i1z
    Tweet 393: @theroyals hey, thanks but that doesn’t sound like me, and I find a bunch of the language on your site problematic.
    Tweet 394: I think I’m going to collect “the best” team pages and toxic statements I see when looking for a new role. Already seen so many.
    
    🤢
    Tweet 395: @Catharz Thanks! I’ve interviewed in the past, but unfortunately, it didn’t fulfil my requirements on diversity and inclusion.
    Tweet 396: @s_mcleod 👋🏻 thanks! unfortunately, I think I’m mostly looking to steer away from traditional front-end roles to so… https://t.co/VJ18W89w3A
    Tweet 397: @stephenbelanger 👋🏻 Elastic has been recommended to me several times now. I would be keen to chat to someone. Would… https://t.co/YOKEU5HWVf
    Tweet 398: @mikerapp haha, please feel free to. I was inspired by wonderful @lrnrd :)
    Tweet 399: @d2kagw @camplexer 👋🏻  sure! would you be able to drop a line at hi@thefox.is with more details, please?
    Tweet 400: @breskeby hey, thanks! unfortunately, I don’t want to pursue the path of a front/JS developer so it wouldn’t be a good fit :)
    Tweet 401: At a conference on whale biology in 1971, a female attendee was photographed but not identified. Last week, a team… https://t.co/lvcWO61ksG
    Tweet 402: The Weinstein Company said it released anyone "who suffered or witnessed any form of sexual misconduct by Harvey We… https://t.co/nHS3fvgzBX
    Tweet 403: British and EU negotiators agreed on the terms of a 21-month Brexit transition https://t.co/VMU82Vx0X2
    Tweet 404: A Facebook executive who urged transparency on Russian disinformation is said to be leaving after clashing with oth… https://t.co/YIe5Pp6zb7
    Tweet 405: 5 important takeaways from China's National People's Congress https://t.co/ktm54IYt4R
    Tweet 406: Videos appear to show individuals casting multiple ballots during Russia's election  https://t.co/CHuJr7GdJ5
    Tweet 407: Britain's government has raised the possibility that it might consider seizing the assets of wealthy Russians like… https://t.co/eoMrHLRvCZ
    Tweet 408: A U.S. soldier in Niger warned that his unit was ill equipped for a raid on a militant. They were sent anyway, and… https://t.co/c4JMwYfTZf
    Tweet 409: RT @nytimesworld: The kidnapping of 110 girls by Boko Haram has left anguished parents asking how such a kidnapping could happen again http…
    Tweet 410: “Send some girls around to the candidate’s house.”
    
    As part of a monthslong investigation into Cambridge Analytica,… https://t.co/yArOs3bQmM
    Tweet 411: RT @ScottShaneNYT: Covering Facebook is a bit like covering the government now, in scale and significance. And @nicoleperlroth @sheeraf can…
    Tweet 412: How to Enjoy Fine Dining on a Fast Food Budget https://t.co/Zvv75ozqhq
    Tweet 413: The Australian comic Hannah Gadsby calls out Louis C.K., Harvey Weinstein and Bill Clinton, but her real target is… https://t.co/VlFMTsQZti
    Tweet 414: RT @nytimesworld: President Bashar al-Assad of Syria took a tour of the eastern Ghouta suburb of Damascus after a government military offen…
    Tweet 415: Can Wikipedia bear the burden of fact-checking YouTube videos? https://t.co/6vZsPdX5z0
    Tweet 416: The shopping gems in Belfast's lively city center are the independently owned establishments https://t.co/AwXscJyNqA
    Tweet 417: RT @UpshotNYT: New research shows that even black boys who grow up wealthy are more likely to wind up poor than to stay rich.
    https://t.co/…
    Tweet 418: Facebook’s chief information security officer, Alex Stamos, is said to have had internal disagreements over how the… https://t.co/bxcrB2UI4o
    Tweet 419: RT @kimseverson: Stuffed ham is a dying art. Or maybe not. Come read about my journey to the land of stuffed ham and decide. https://t.co/9…
    Tweet 420: Facebook’s open platform for third-party apps helped it grow into a juggernaut. But it’s become a privacy nightmare. https://t.co/HUEJOTDUCF
    Tweet 421: RT @marclacey: Can you believe it’s been six months since Harvey flooded Houston? Here’s a powerful look by @nytvideo at one neighborhood t…
    Tweet 422: As President Trump openly discussed firing one of his lawyers, another considered resigning and a third — who pushe… https://t.co/t6nEelnV6l
    Tweet 423: Mississippi has imposed a ban on abortions after 15 weeks. The state's only abortion clinic immediately sued to blo… https://t.co/KqLmc4NspZ
    Tweet 424: RT @kevinroose: New by me: Facebook’s open platform for third-party apps helped it grow into a juggernaut. But it’s become a privacy nightm…
    Tweet 425: 4 easy ways to cut down your sugar intake https://t.co/rRf9xm6WHS
    Tweet 426: RT @nytmike: Dowd wants to quit. Trump’s talking about firing Cobb. Another lawyer — who says FBI made up evidence against Trump — was hire…
    Tweet 427: The brother of Nikolas Cruz was charged with trespassing at Marjory Stoneman Douglas High School on Monday, the aut… https://t.co/h0o2gTJ7HO
    Tweet 428: Audit your Facebook apps, audit your Facebook privacy settings, and 5 other tips for protecting your data on Facebo… https://t.co/t87b7WJjZH
    Tweet 429: Claire’s, the teen jewelry chain known for its ear-piercing services, filed for Chapter 11 bankruptcy protection https://t.co/mn4hvSQjkf
    Tweet 430: The Supreme Court rejected an emergency request from Pennsylvania Republicans to block new congressional voting dis… https://t.co/DeLYEPkfdu
    Tweet 431: RT @sheeraf: To be clear: We spoke to seven current and former Facebook employees for this story on how internal disputes over FB's role in…
    Tweet 432: A U.S. soldier in Niger warned that his unit was ill equipped for a raid on a militant. They were sent anyway, and… https://t.co/0U7C8aSiyP
    Tweet 433: Evening Briefing: Here's what you need to know at the end of the day https://t.co/HYYSMwnO4R
    Tweet 434: After we published an article on tipping and the power imbalance it creates between customers and servers, readers… https://t.co/LJx3uSo2dF
    Tweet 435: RT @sheeraf: Full story now up. Alex Stamos is the first Facebook executive to leave the company, amid growing internal tensions over disin…
    Tweet 436: At a conference on whale biology in 1971, a female attendee was photographed but not identified. Last week, a team… https://t.co/BfdgD7NSnJ
    Tweet 437: RT @nytopinion: Despite Facebook’s claims, everyone involved in the Cambridge Analytica data-siphoning incident did not give his or her “co…
    Tweet 438: Mary Outerbridge set up a tennis court in Staten Island in her 20s. It may have been the first in the U.S. https://t.co/MrVl8V3Mll
    Tweet 439: New York City’s subway hit a new low in January: Just 58.1% of weekday trains arrived on time. The MTA blamed bad w… https://t.co/AjE2LhnBWu
    Tweet 440: RT @KevinQ: The worst places for poor white children are almost all better than the best places for poor black children.
    
    https://t.co/EPZt…
    Tweet 441: Evening Briefing: Here's what you need to know at the end of the day https://t.co/tQvejB0Xpm
    Tweet 442: RT @nicoleperlroth: NEW: Facebook's security officer @alexstamos is leaving the company amid disagreements with Facebook execs over how to…
    Tweet 443: Alex Stamos is said to be leaving Facebook after internal disagreements over how the social network should deal wit… https://t.co/2tbsL4WojM
    Tweet 444: Breaking News: A Facebook executive who urged transparency on Russian disinformation is said to be leaving after cl… https://t.co/iFVb6BY6j7
    Tweet 445: RT @UpshotNYT: The Supreme Court today refused to Intervene in the Pa. redistricting case. That means these districts are holding up, and D…
    Tweet 446: Photographers find new ways to frame the natural world https://t.co/dSKQ3jE90n https://t.co/2oMSS8Vyi9
    Tweet 447: RT @julieturkewitz: Tweeting some of the reaction to our story today: "I have long thought the absence of Native Americans from any form of…
    Tweet 448: Al Pacino and Michelle Pfeiffer will reunite for a 35th anniversary screening of "Scarface" at the Tribeca Film Fes… https://t.co/CHjotO0oT8
    Tweet 449: “Send some girls around to the candidate’s house.”
    
    As part of a monthslong investigation into Cambridge Analytica,… https://t.co/YP7xSJ59Gx
    Tweet 450: RT @readercenter: A @nytimes article published today on race and the income gap led to a big discussion among our readers. Submit a questio…
    Tweet 451: Catharine MacKinnon: "People have asked me for 40 years how not to get sued for sexual harassment. Well, a good fir… https://t.co/aiuh7NXSzK
    Tweet 452: Justin Verlander brought value to the Astros last season, when he joined in a trade and helped them win the World S… https://t.co/8yl93W3HoA
    Tweet 453: “Everyone in Austin is in the process of trying to figure out exactly how nervous to be. Are these bombings targete… https://t.co/5Pg0Ep4PRR
    Tweet 454: Read our report on how servers and bartenders weigh harassing behavior from customers against the tips they need to… https://t.co/N9dFagqWIa
    Tweet 455: Our report on the sexual harassment endured by restaurant servers drew 1,200 responses from readers: on money, powe… https://t.co/VnCiSwIYgy
    Tweet 456: RT @nytimestravel: Do you see Wakanda as a series of magical neighborhoods floating in midair? Would the magnetic levitation subway in trav…
    Tweet 457: “Send some girls around to the candidate’s house”: As part of a monthslong investigation into Cambridge Analytica,… https://t.co/FMEWKpKCUa
    Tweet 458: However, the firm’s employees, who often overlap, had contact in 2014 and 2015 with executives from Lukoil, the Rus… https://t.co/8Q90TwYuIH
    Tweet 459: Alexander Nix, a director of SCL Group, a British political and defense contractor, and chief executive of its Amer… https://t.co/CZMF8buD3n
    Tweet 460: Facebook is defending its protection of user information after Cambridge Analytica harvested private information fr… https://t.co/ynmgpzkUa8
    Tweet 461: Christopher Wylie, who oversaw Cambridge’s data collection until 2014, said of his former company, “For them, this… https://t.co/lGYdQTfkLz
    Tweet 462: The New York Times and The Observer of London reported how Cambridge Analytica, a political data firm closely tied… https://t.co/iu6g0OHg5T
    Tweet 463: Here’s what you need to know about how a political data firm tied to President Trump’s campaign gained access to pr… https://t.co/zvnAIgGXbv
    Tweet 464: "Nipped waists have long represented femininity," @AlexanderFury writes. "What does it say about the contemporary m… https://t.co/30rkCxLYYD
    Tweet 465: RT @NYTmag: These are chicks of the endangered Akikiki bird, a small bird native to the forests of Kauai, Hawaii. https://t.co/Wx1KGuzIk7 h…
    Tweet 466: The Australian comic Hannah Gadsby calls out Louis C.K., Harvey Weinstein and Bill Clinton, but her real target is… https://t.co/9lsfWqknha
    Tweet 467: The fourth bombing in Austin demonstrated a higher level of sophistication than the previous 3, as well as a “signi… https://t.co/uLMo7jGk5b
    Tweet 468: This video is the first piece in a series about these residents. Their stories offer a look at how people are confr… https://t.co/NLB5u8MLra
    Tweet 469: In the 6 months since Harvey, The New York Times followed several families in the Cinco Ranch community as they str… https://t.co/naAH2tvhPx
    Tweet 470: The homes in Cinco Ranch sat on land that had been designed to flood — a fact that wasn’t widely publicized when a… https://t.co/qAwdPWE5WV
    Tweet 471: After Hurricane Harvey swamped Houston, some residents of one suburban area were shocked to learn that the flooding… https://t.co/QYRyJRcO7D
    Tweet 472: RT @tiffkhsu: Claire's, where I and all of my friends and all of their friends got ears pierced as teenagers, is filing for Chapter 11 bank…
    Tweet 473: Does New York want another celebrity in public office? The actress Cynthia Nixon hopes so: She just entered the rac… https://t.co/tmzrIs6quF
    Tweet 474: RT @julieturkewitz: For much of our country's history, native people weren't permitted to vote. Now there are a historic number of indigeno…
    Tweet 475: 4 bombings this month in Austin, including one on Sunday night, have killed 2 people and injured 4. Here's what we… https://t.co/bqa42mRTn7
    Tweet 476: Another reader reacts to the news that a woman died after being hit by a self-driving Uber car… https://t.co/z1uax6tzgG
    Tweet 477: A New York Times reader reacts to the news that a woman died after being hit by a self-driving Uber car… https://t.co/1Tm0f1qpdM
    Tweet 478: You'll probably need to do a little shopping to make this traditional dish. But it's well worth it. https://t.co/8sjpx5xcn7
    Tweet 479: RT @NYTSports: Tyronn Lue: “I have had chest pains and other troubling symptoms." He's stepping away from the Cavs with just 13 games left…
    Tweet 480: Andrew McCabe, the former FBI deputy director, was fired late Friday night — on the eve of his retirement. Here’s w… https://t.co/WgdgoA0WtP
    Tweet 481: Stuffed ham is one of America’s most regionally specific dishes. People in Southern Maryland cherish it. https://t.co/g2tDQy5xWK
    Tweet 482: One NYT reader embraces the practice of flirting for tips https://t.co/bzmsCpF0sp https://t.co/35aiorjdej
    Tweet 483: RT @jasondhorowitz: Luigi Di Maio, 31, and Italy's potential next leader, was living at home “until five years ago,” his mother tells me. M…
    Tweet 484: President Trump is planning to hire a lawyer who’s pushed theories on Fox News that Trump was framed by the FBI and… https://t.co/W8oVqa5D2I
    Tweet 485: The change of a single word in the new tax law means the MLB, NBA and other sports franchises could now face capita… https://t.co/NBcgIvPN2X
    Tweet 486: Breaking News: A woman died after being hit by a self-driving Uber car in Tempe, Arizona. It’s the first known pede… https://t.co/KqD9AUqOm5
    Tweet 487: RT @nytopinion: I am a junior in high school, and I regularly shoot guns, for target practice and hunting, writes Dakota Hanchett https://t…
    Tweet 488: Britain will have a transition period after the country withdraws from the EU — as long as a deal can be struck to… https://t.co/j3M7RRrd5d
    Tweet 489: What we know about the Austin bombings https://t.co/EfHgpraY8B
    Tweet 490: The Austin police chief sent an unusual public message to the unknown bomber or bombers on Sunday: "We assure you t… https://t.co/BYmbbRdr6n
    Tweet 491: RT @NYTMetro: Prewar walk-up, airy loft, garden flat or sky-high glass-and-steel cube — we took a look at the history of the New York City…
    Tweet 492: After we published an article examining how servers endure harassing behavior for tips, readers wrote in with their… https://t.co/2zaaCSwtzd
    Tweet 493: In her early 20s, Mary Ewing Outerbridge brought tennis to the U.S. in the 1870s, establishing what may have been A… https://t.co/vqkNjr5uhs
    Tweet 494: Michael Ferro stepped down as the chairman of Tronc, just weeks after he helped negotiate the sale of The Los Angel… https://t.co/2ctT8mAELY
    Tweet 495: YouTube announced it would enlist Wikipedia’s help to deal with the proliferation of conspiracy theories and misinf… https://t.co/BRgKu7qgmR
    Tweet 496: RT @nhannahjones: An absolutely devastating new study about race and black males. Sons of wealthy black parents no better off than sons of…
    Tweet 497: There’s never been a Native American congresswoman. That could change in 2018. https://t.co/sWz8dv2SQ5
    Tweet 498: RT @NYTNational: “Rules don’t matter for them. For them, this is a war, and it’s all fair," said a founder of Cambridge Analytica, a firm t…
    Tweet 499: “Our community never should have been developed. It’s hundreds and hundreds of houses. Now we are proof that we nee… https://t.co/jlC1TJJ7JE
    Tweet 500: After Hurricane Harvey, thousands of homes in a Houston suburb were deliberately flooded by the federal government.… https://t.co/x3cwgQEQkr
    


```python
#Creating a DataFrame for the News mood Tweets
sentiments_df=pd.DataFrame.from_dict(sentiments)#check

#Saving the DataFrame to a CSV file
sentiments_csv.to_csv("News Mood Tweets.csv")

```


```python
sentiments_csv= sentiments_df[['Media Source','Date','Text','Compound','Positive','Neutral','Negative','Tweet Count']]
sentiments_csv.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Media Source</th>
      <th>Date</th>
      <th>Text</th>
      <th>Compound</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Tweet Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:33 +0000 2018</td>
      <td>RT @BBCOne: They've finally quacked the case.\...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:23 +0000 2018</td>
      <td>RT @BBCEarth: Sudan’s death leaves just two fe...</td>
      <td>-0.3182</td>
      <td>0.127</td>
      <td>0.683</td>
      <td>0.190</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:10 +0000 2018</td>
      <td>RT @bbcthree: RuPaul is the first drag queen t...</td>
      <td>0.2500</td>
      <td>0.133</td>
      <td>0.780</td>
      <td>0.087</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:02 +0000 2018</td>
      <td>RT @BBCBreakfast: ❄️❄️BBRRR....Could it be the...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:32:02 +0000 2018</td>
      <td>Meet Bumblebee and Gnat, two adorable badger c...</td>
      <td>0.4939</td>
      <td>0.186</td>
      <td>0.814</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentiments_csv['Media Source'] = sentiments_csv['Media Source'].map(lambda x: x.lstrip('@'))
sentiments_csv.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Media Source</th>
      <th>Date</th>
      <th>Text</th>
      <th>Compound</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Tweet Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BBC</td>
      <td>Tue Mar 20 09:49:33 +0000 2018</td>
      <td>RT @BBCOne: They've finally quacked the case.\...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BBC</td>
      <td>Tue Mar 20 09:49:23 +0000 2018</td>
      <td>RT @BBCEarth: Sudan’s death leaves just two fe...</td>
      <td>-0.3182</td>
      <td>0.127</td>
      <td>0.683</td>
      <td>0.190</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BBC</td>
      <td>Tue Mar 20 09:49:10 +0000 2018</td>
      <td>RT @bbcthree: RuPaul is the first drag queen t...</td>
      <td>0.2500</td>
      <td>0.133</td>
      <td>0.780</td>
      <td>0.087</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BBC</td>
      <td>Tue Mar 20 09:49:02 +0000 2018</td>
      <td>RT @BBCBreakfast: ❄️❄️BBRRR....Could it be the...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BBC</td>
      <td>Tue Mar 20 09:32:02 +0000 2018</td>
      <td>Meet Bumblebee and Gnat, two adorable badger c...</td>
      <td>0.4939</td>
      <td>0.186</td>
      <td>0.814</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plotting a Scatter Plot for the news mood Tweets
# reference colors
media_colors_format={"BBC": "lightblue",
             "CBS":"green", 
             "CNN":"red",
             "Fox":"blue",
             "nytimes": "yellow"}


```


```python
sns.set()
plt.figure(figsize = (15,10))
plt.xlabel("Tweets Ago",fontweight='bold')
plt.ylabel("Tweet Polarity",fontweight='bold')
plt.title("Sentiment Analysis of Media Tweets (%s)" % (time.strftime("%m/%d/%Y")),fontweight='bold')
plt.xlim(102,-2, -1)
plt.ylim(-1,1)
for newsoutlet in news_colors.keys():
    df = sentiments_csv[sentiments_csv['Media Source'] == newsoutlet]
    sentiment_analysis = plt.scatter(df["Tweet Count"],df["Compound"], label = newsoutlet, color = news_colors[newsoutlet], edgecolor = "black", s=125)
plt.legend(bbox_to_anchor = (1,1), title = 'Media Sources')    
plt.show()
sentiment_analysis.figure.savefig('SentimentAnalysis.png')

```


![png](output_9_0.png)



```python
scoresbyoutlet=sentiments_media_csv.groupby("Media Source")["Compound"].mean()
scoresbyoutlet
```




    Media Source
    BBC        0.144423
    CBS        0.304366
    CNN       -0.100556
    Fox        0.179096
    nytimes   -0.041687
    Name: Compound, dtype: float64




```python
sentiments_csv= sentiments_df[['Media Source','Date','Text','Compound','Positive','Neutral','Negative','Tweet Count']]
sentiments_csv.head(20)

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Media Source</th>
      <th>Date</th>
      <th>Text</th>
      <th>Compound</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Tweet Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:33 +0000 2018</td>
      <td>RT @BBCOne: They've finally quacked the case.\...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:23 +0000 2018</td>
      <td>RT @BBCEarth: Sudan’s death leaves just two fe...</td>
      <td>-0.3182</td>
      <td>0.127</td>
      <td>0.683</td>
      <td>0.190</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:10 +0000 2018</td>
      <td>RT @bbcthree: RuPaul is the first drag queen t...</td>
      <td>0.2500</td>
      <td>0.133</td>
      <td>0.780</td>
      <td>0.087</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:49:02 +0000 2018</td>
      <td>RT @BBCBreakfast: ❄️❄️BBRRR....Could it be the...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:32:02 +0000 2018</td>
      <td>Meet Bumblebee and Gnat, two adorable badger c...</td>
      <td>0.4939</td>
      <td>0.186</td>
      <td>0.814</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>@BBC</td>
      <td>Tue Mar 20 09:03:04 +0000 2018</td>
      <td>Spring is here! But what is the #SpringEquinox...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>@BBC</td>
      <td>Tue Mar 20 08:25:06 +0000 2018</td>
      <td>Five times Beyonce and Jay-Z’s daughter Blue I...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>@BBC</td>
      <td>Tue Mar 20 08:03:03 +0000 2018</td>
      <td>Traditional Highland Games sports such as toss...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>@BBC</td>
      <td>Mon Mar 19 19:33:04 +0000 2018</td>
      <td>Follow the dramatic and deadly series of event...</td>
      <td>-0.3818</td>
      <td>0.000</td>
      <td>0.890</td>
      <td>0.110</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>@BBC</td>
      <td>Mon Mar 19 18:33:05 +0000 2018</td>
      <td>Leonardo DiCaprio stars in the true story of a...</td>
      <td>0.1531</td>
      <td>0.175</td>
      <td>0.709</td>
      <td>0.116</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>@BBC</td>
      <td>Mon Mar 19 18:03:01 +0000 2018</td>
      <td>😂📸 @AlanCarr learned the hard way that you onl...</td>
      <td>-0.1027</td>
      <td>0.000</td>
      <td>0.920</td>
      <td>0.080</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>@BBC</td>
      <td>Mon Mar 19 17:30:08 +0000 2018</td>
      <td>🎤Pop band @FifthHarmony have announced they're...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>@BBC</td>
      <td>Mon Mar 19 17:00:05 +0000 2018</td>
      <td>Murder. Innocence. Lies. \n\n@AgathaChristie c...</td>
      <td>-0.7096</td>
      <td>0.144</td>
      <td>0.442</td>
      <td>0.414</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>@BBC</td>
      <td>Mon Mar 19 16:33:29 +0000 2018</td>
      <td>Here are the latest snow scenes from around th...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>@BBC</td>
      <td>Mon Mar 19 15:02:02 +0000 2018</td>
      <td>'Flabbergasted'. 🎶This is the incredible momen...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>@BBC</td>
      <td>Mon Mar 19 14:30:08 +0000 2018</td>
      <td>Meet the dancing slum kids tipped for stardom ...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>@BBC</td>
      <td>Mon Mar 19 13:44:55 +0000 2018</td>
      <td>RT @bbcgetinspired: The Nation's Billion Steps...</td>
      <td>0.6588</td>
      <td>0.212</td>
      <td>0.788</td>
      <td>0.000</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>@BBC</td>
      <td>Mon Mar 19 13:03:04 +0000 2018</td>
      <td>💭 "There's always that voice in the back of yo...</td>
      <td>-0.3412</td>
      <td>0.000</td>
      <td>0.888</td>
      <td>0.112</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>@BBC</td>
      <td>Mon Mar 19 12:55:17 +0000 2018</td>
      <td>RT @BBCRadioScot: This must have been some buz...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>@BBC</td>
      <td>Mon Mar 19 12:30:05 +0000 2018</td>
      <td>Where are the UK's youngest and oldest city po...</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
x_axis=np.arange(len(scoresbyoutlet))
# x_axis.head()
```


```python
# Plotting the bar chart for the news mood tweets
sns.set()

plt.figure(figsize = (10,8))
for newsoutlet in news_colors.keys():
    df = sentiments_csv[sentiments_csv['Media Source'] == newsoutlet]
#     print (news_colors[newsoutlet])
   
    overall_media_sentiment = plt.bar(x_axis,scoresbyoutlet, color = {"lightblue","green", "yellow", "red", "blue"}, label = newsoutlet, edgecolor = "black")
    
# plt.bar(x_axis,scoresbyoutlet, label = newsoutlet, color = news_colors[newsoutlet], edgecolor = "black")
plt.ylim(-.2, .4)
plt.ylabel("Tweet Polarity",fontweight='bold')
plt.axhline(y=0, color = 'black') 
for i, v in enumerate(scoresbyoutlet):
    plt.text(i-.3, v+.03, str(v).format(), color='black', fontweight='bold')
plt.title("Overall Media Sentiment Based on Twitter (%s)" % (time.strftime("%m/%d/%Y")),fontweight='bold')
x_labels = ["BBC", "CBS", "CNN", "Fox", "NYT"]
x_locations = [value for value in np.arange(6)]
plt.xticks(x_locations, x_labels)
plt.show()
plt.savefig('Overall Media Sentiment Based on Twitter.png')

```


    <matplotlib.figure.Figure at 0x1ab71875128>



![png](output_13_1.png)



```python
3 #Observations:

# Looking at the Bar Chart, i discovered that CNN and New York Times, Most especially CNN had the most negative sentimntal tweet 
#as at 03/20/2018 while CBS had the Most Positive Sentiments in their tweets. 

#Also judging from the Scatter Plot graph, the NewYork Times almost dominate the neutral Line, although a little bit negative 
#from their tweets 

#Lastly BBC and Fox News maintained a Positive sentimental tweets which is similar to CBS as at 03/20/2018.
```




    3


